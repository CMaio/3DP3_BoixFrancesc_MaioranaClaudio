﻿using System.Collections;
using System.Collections.Generic;
using Unity.Burst;
using UnityEngine;

public class Move : MonoBehaviour
{
    public Vector3 speed;
    [SerializeField] float cubeSize;

    void FixedUpdate()
    {
        transform.position += speed * Time.deltaTime;
        if (transform.position.x < 0.0f)
        {
            speed = new Vector3(-speed.x, speed.y, speed.z);
            transform.position = new Vector3(0.0f, transform.position.y, transform.position.z);
        }
        if (transform.position.x > cubeSize)
        {
            speed = new Vector3(-speed.x, speed.y, speed.z);
            transform.position = new Vector3(cubeSize, transform.position.y, transform.position.z);
        }
        if (transform.position.y < 0.0f)
        {
            speed = new Vector3(speed.x, -speed.y, speed.z);
            transform.position = new Vector3(transform.position.x, 0.0f, transform.position.z);
        }
        if (transform.position.y > cubeSize)
        {
            speed = new Vector3(speed.x, -speed.y, speed.z);
            transform.position = new Vector3(transform.position.x, cubeSize, transform.position.z);
        }
        if (transform.position.z < 0.0f)
        {
            speed = new Vector3(speed.x, speed.y, -speed.z);
            transform.position = new Vector3(transform.position.x, transform.position.y, 0.0f);
        }
        if (transform.position.z > cubeSize)
        {
            speed = new Vector3(speed.x, speed.y, -speed.z);
            transform.position = new Vector3(transform.position.x, transform.position.y, cubeSize);
        }
    }
}
