﻿using System.Collections;
using System.Collections.Generic;
using Unity.Burst;
using UnityEngine;

public class BallsCreatorV1 : MonoBehaviour
{
    [SerializeField] GameObject prefab;
    [SerializeField] int numInstances;

    [SerializeField] TMPro.TextMeshProUGUI text_balls;

    int totalBalls = 0;

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            for(int i=0; i<numInstances; i++)
            {
                GameObject go = Instantiate(prefab);
                go.transform.position = new Vector3(
                    Random.Range(0.0f, 100.0f),
                    Random.Range(0.0f, 100.0f),
                    Random.Range(0.0f, 100.0f));
                go.GetComponent<Move>().speed = new Vector3(
                    Random.Range(-10.0f, 10.0f),
                    Random.Range(-10.0f, 10.0f),
                    Random.Range(-10.0f, 10.0f)
                    );
            }
            totalBalls += numInstances;
            text_balls.text = totalBalls + " BALLS";
        }
    }
}
