﻿using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;
using Unity.Burst;
using Unity.Jobs;

public struct MoveComponentV4 : IComponentData
{
    public float3 speed;
    public float cubeSize;
}
public class MoveSystemV4 : SystemBase
{
    protected override void OnUpdate()
    {
        float delta = Time.DeltaTime;
        Entities.ForEach((ref Translation translation, ref MoveComponentV4 move) =>
        {
            
            translation.Value += move.speed * delta;
            if (translation.Value.x < 0.0f)
            {
                translation.Value.x = 0.0f;
                move.speed.x = -move.speed.x;
            }
            if (translation.Value.x > move.cubeSize)
            { 
                translation.Value.x = move.cubeSize;
                move.speed.x = -move.speed.x;
            }
            if (translation.Value.y < 0.0f)
            {
                translation.Value.y = 0.0f;
                move.speed.y = -move.speed.y;
            }
            if (translation.Value.y > move.cubeSize)
            {
                translation.Value.y = move.cubeSize;
                move.speed.y = -move.speed.y;
            }
            if (translation.Value.z < 0.0f)
            {
                translation.Value.z = 0.0f;
                move.speed.z = -move.speed.z;
            }
            if (translation.Value.z > move.cubeSize)
            {
                translation.Value.z = move.cubeSize;
                move.speed.z = -move.speed.z;
            }
        }
        ).ScheduleParallel();
    }
}
