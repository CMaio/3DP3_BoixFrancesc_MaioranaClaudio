﻿using System.Collections;
using System.Collections.Generic;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;


public class BallsCreatorV2 : MonoBehaviour
{

    [SerializeField] int numInstances;

    [SerializeField] TMPro.TextMeshProUGUI text_balls;

    int totalBalls = 0;

    EntityManager entityManager;
    EntityArchetype entityArchetype;

    private void Start()
    {
        entityManager = World.DefaultGameObjectInjectionWorld.EntityManager;
        entityArchetype = entityManager.CreateArchetype(
            typeof(Translation),
            typeof(MoveComponentV2)
            );
    }

    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            NativeArray<Entity> entityArray = new NativeArray<Entity>(numInstances, Allocator.Temp);
            entityManager.CreateEntity(entityArchetype, entityArray);
            for(int i=0; i<numInstances; i++)
            {
                Entity e = entityArray[i];
                entityManager.SetComponentData(e,
                    new MoveComponentV2
                    {
                        speed = new float3(
                            UnityEngine.Random.Range(-10.0f, 10.0f),
                            UnityEngine.Random.Range(-10.0f, 10.0f),
                            UnityEngine.Random.Range(-10.0f, 10.0f)),
                        cubeSize = 100.0f
                    });
                entityManager.SetComponentData(e,
                    new Translation
                    {
                        Value = new float3(
                            UnityEngine.Random.Range(0.0f, 100.0f),
                            UnityEngine.Random.Range(0.0f, 100.0f),
                            UnityEngine.Random.Range(0.0f, 100.0f))
                    });
            }
            totalBalls += numInstances;
            text_balls.text = totalBalls + " BALLS";
        }
    }
}
