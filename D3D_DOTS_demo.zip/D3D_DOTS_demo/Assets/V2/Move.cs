﻿using System.Collections;
using System.Collections.Generic;
using Unity.Burst;
using Unity.Entities;
using Unity.Mathematics;
using Unity.Transforms;
using UnityEngine;




public struct MoveComponentV2 : IComponentData
{
    public float3 speed;
    public float cubeSize;
}

public class MoveSystemV2 : ComponentSystem
{
    protected override void OnUpdate()
    {
        Entities.ForEach((ref Translation translation, ref MoveComponentV2 move) =>
        {
            translation.Value += move.speed * Time.DeltaTime;
            if (translation.Value.x < 0.0f)
            {
                translation.Value.x = 0.0f;
                move.speed.x = -move.speed.x;
            }
            if (translation.Value.x > move.cubeSize)
            { 
                translation.Value.x = move.cubeSize;
                move.speed.x = -move.speed.x;
            }
            if (translation.Value.y < 0.0f)
            {
                translation.Value.y = 0.0f;
                move.speed.y = -move.speed.y;
            }
            if (translation.Value.y > move.cubeSize)
            {
                translation.Value.y = move.cubeSize;
                move.speed.y = -move.speed.y;
            }
            if (translation.Value.z < 0.0f)
            {
                translation.Value.z = 0.0f;
                move.speed.z = -move.speed.z;
            }
            if (translation.Value.z > move.cubeSize)
            {
                translation.Value.z = move.cubeSize;
                move.speed.z = -move.speed.z;
            }
        }
        );
    }
}
